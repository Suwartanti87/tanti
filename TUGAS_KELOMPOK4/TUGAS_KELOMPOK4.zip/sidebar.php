<div class="row">
		<div class="col-md-3">
			<div class="list-group">
				 <a href="#" class="list-group-item list-group-item-action active">Information</a>
				<div class="list-group-item">
					<ul class="navbar-nav">
						<li class="nav-item">
							 <a class="nav-link" href="#">Struktur Organisasi Sekolah</a>
						</li>
						<li class="nav-item active">
							 <a class="nav-link" href="#">Data Staff <span class="sr-only">(current)</span></a>
						</li>
						<li class="nav-item">
							 <a class="nav-link" href="#">Data Guru</a>
						</li>
						<li class="nav-item">
							 <a class="nav-link" href="index.php?fat=siswa">Data Siswa</a>
						</li>
						<li class="nav-item">
							 <a class="nav-link" href="#">Data Rombel</a>
						</li>
						
						
					</ul>
				
				</a>
			</div>
		</div>
		</div>

