<?php
//tangkap request di url dari klik tombol detail
$id = $_GET['idsis'];
$model = new SiswaModel();
$rs = $model->view([$id]);

print_r($rs); exit;
foreach ($rs as $sis) {
	$nama = $id->nama;


?>

<?php } ?>
<div class="card" style="width: 18rem;">
  <img src="gambar/1.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title"><?= $nama ?></h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div>

