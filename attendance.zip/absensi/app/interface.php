<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class interface extends Model
{
 protected $table = 'interface';
}
