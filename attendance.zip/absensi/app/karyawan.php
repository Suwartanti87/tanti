<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class karyawan extends Model
{
/*
 protected $table = 'karyawan';
 protected $fillable = ['nama_karyawan','tgl_lahir','jenis_kelamin','agama','alamat','tgl_masuk','tgl_keluar','user_id'];
 */
 protected $table = 'karyawan';
}
