<table border="1" >
	<thead>
		<tr bgcolor="lightblue">
			<th>No</th>
			<th>Nama</th>
			<th>Tempat,Tanggal Lahir</th>
			<th>Jenis Kelamin</th>
			<th>Posisi</th>
			<th>No HP</th>
			<th>Status</th>
			<th>Alamat</th>
		</tr>
	</thead>
	<tbody>
		<?php
		$no = 1;
		?>

		<?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
		<td><?php echo e($no++); ?></td>
		<td><?php echo e($kar->nama); ?></td>
		<td><?php echo e($kar->tempat_lahir); ?>,<?php echo e($kar->tgl_lahir); ?></td>
		<td><?php echo e($kar->jenis_kelamin); ?></td>
		<td><?php echo e($kar->jabatan_id); ?></td>
		<td><?php echo e($kar->no_hp); ?></td>
		<td><?php echo e($kar->status); ?></td>
		<td><?php echo e($kar->alamat); ?></td>
		</tr>
		
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table><?php /**PATH C:\xampp\htdocs\absensi\resources\views/export/karyawanpdf.blade.php ENDPATH**/ ?>