<?php $__env->startSection('content'); ?>

<div class="card o-hidden border-0 shadow-lg my-5">
<div class="card-body p-0">
<div class="container">
  <div class="main">
    <div class="main-center"><br/>
      <h1>Edit Posisi</h1><br/>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <form action="<?php echo e(route('posisi.update',$d->id)); ?>" method="POST">
 	<?php echo e(csrf_field()); ?>


  <div class="form-group">
    <input name="posisi" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="masukan posisi anda" value="<?php echo e($d->posisi); ?>">
  </div>
  
     
      <div class="modal-footer">
        <button value="<?php echo e(url('/karyawan')); ?>" type="submit" class="btn btn-warning">Update</button>
      </div>
  </form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
    </div>
  </div>
</div>
</div>

  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\composer\absensi\resources\views/posisi/update.blade.php ENDPATH**/ ?>