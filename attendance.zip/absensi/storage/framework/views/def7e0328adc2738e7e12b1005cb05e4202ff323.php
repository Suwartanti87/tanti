 
<?php $__env->startSection('content'); ?>

<div class="card o-hidden border-0 shadow-lg my-5">
<div class="card-body p-0">
<div class="container">
  <div class="main">
    <div class="main-center"><br/>
      <h3>Edit Form Pegawai</h3><br/>


      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <form class="user" method="POST" action="<?php echo e(route('karyawan.update',$d->id)); ?>" enctype="multipart/form-data">
         <?php echo e(csrf_field()); ?>

        <?php echo method_field('PUT'); ?>      
        <div class="form-group row">
          <div class="col-sm-6 mb-3 mb-sm-0">
          <label for="exampleInputEmail1">Nama Lengkap : </label>
          <input name="nama" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="ketik nama lengkap anda" value="<?php echo e($d->nama); ?>">
        </div>
        <div class="col-sm-6">
          <label>Posisi : </label>
                <?php
                //ambil dari posisi = select * from posisi
                $rs = App\Posisi::all()
                ?>
                <select name="jabatan_id" class="form-control">
                  <option value="">-- Pilih Posisi --</option>
                  <?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                  //edit data lama
                  $sel = ($d->jabatan_id == $row->id) ? 'selected' : '';
                  ?>
                  <option value="<?php echo e($row->id); ?>" <?php echo e($sel); ?>><?php echo e($row->posisi); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
        </div>
      </div>
        <div class="form-group row">
          <div class="col-sm-6 mb-3 mb-sm-0">
          <label for="exampleInputEmail1">Tempat Lahir : </label>
          <input name="tempat_lahir" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="ketik tempat lahir anda" value="<?php echo e($d->tempat_lahir); ?>">
        </div>
        <div class="col-sm-6">
          <label for="exampleInputEmail1">Tanggal Lahir : </label>
          <input name="tgl_lahir" value="<?php echo e($d->tgl_lahir); ?>" type="date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="YYYY-MM-DD">
        </div>
      </div>
        <div class="form-group row">
          <div class="col-sm-6 mb-3 mb-sm-0">
          <?php
          $ar_jk = ['L','P'];
          ?>
          <label>Jenis Kelamin : </label>
          <br/>
          <?php $__currentLoopData = $ar_jk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
          //edit data lama
          $cek = ($d->jenis_kelamin == $jk) ? 'checked' : '';
          ?>
          <div class="form-check form-check-inline">
          <input type="radio" class="form-check-input" name="jenis_kelamin" value="<?php echo e($jk); ?>" <?php echo e($cek); ?>>                    
          <label class="form-check-label"><?php echo e($jk); ?></label>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-sm-6">
          <?php
          $ar_agama = ['Islam','Kristen','Hindu','Buddha','Konghuchu','Others'];
          ?>
          <label>Agama : </label>
          <br/>
          <?php $__currentLoopData = $ar_agama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
          //edit data lama
          $cek3 = ($d->agama == $agama) ? 'checked' : '';
          ?>
          <div class="form-check form-check-inline">
          <input type="radio" class="form-check-input" name="agama" value="<?php echo e($agama); ?>" <?php echo e($cek3); ?>>                    
          <label class="form-check-label"><?php echo e($agama); ?></label>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
        <div class="form-group row">
          <div class="col-sm-6 mb-3 mb-sm-0">
          <label for="exampleFormControlTextarea1">Alamat : </label>
          <textarea name="alamat" class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="ketik alamat anda"><?php echo e($d->alamat); ?></textarea>
        </div>
        <div class="col-sm-6">
        <?php
        $ar_status = ['Menikah','Belum'];
        ?>
        <label>Status : </label>
        <br/>
        <?php $__currentLoopData = $ar_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        //edit data lama
        $cek2 = ($d->status == $status) ? 'checked' : '';
        ?>
        <input type="radio" class=" form-control-input" name="status" value="<?php echo e($status); ?>" <?php echo e($cek2); ?>> <?php echo e($status); ?> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
        <div class="form-group row">
          <div class="col-sm-6 mb-3 mb-sm-0">
          <label for="exampleInputEmail1">No. Hp : </label>
          <input name="no_hp" value="<?php echo e($d->no_hp); ?>" type="number" class="form-control"  aria-describedby="emailHelp" placeholder="ketik no.hp anda">
          
        </div>
        <div class="col-sm-6">
          <label for="exampleInputEmail1">Foto : </label>
          <input name="foto" type="file" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="">
        </div>
      </div>
        <div class="form-group row">
          <div class="col-sm-6 mb-3 mb-sm-0">
          <label for="exampleInputEmail1">Tanggal Gabung : </label>
          <input name="tgl_masuk" value="<?php echo e($d->tgl_gabung); ?>" type="date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="YYYY-MM-DD">
        </div>
        <div class="col-sm-6">
          <label for="exampleInputEmail1">Tanggal Keluar : </label>
          <input name="tgl_keluar" value="<?php echo e($d->tgl_keluar); ?>" type="date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="YYYY-MM-DD">
        </div>
      </div>
        <br/>
        <center>
        <button value="" type="submit" class="btn btn-dark">Ubah</button>
      </center>
        <br/>
      </form>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
    </div><!--main-center"-->
  </div><!--main-->
</div><!--container-->

</body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\absensi\resources\views/karyawan/update.blade.php ENDPATH**/ ?>