<?php $__env->startSection('content'); ?>
<?php
$ar_judul = ['No','Nama Karyawan','Tanggal','Time In','Time Out','Action'];
$no = 1;
?>

<section>
  <div class="container">
    <img class="img-fluid rounded about-heading-img mb-3 mb-lg-0" src="img/absensi.jpg" alt="" align="center">
    <div class="about-heading-content">
      <div class="row">
        <div class="col-xl-12 col-lg-12 mx-auto">
          <div class="bg-faded rounded p-5">

            <h1 class="btn-warning" align="center">Jadwal Karyawan</h1>

            <!-- Button trigger modal -->
            <button type="button" class="btn btn-warning btn-sm " data-toggle="modal" data-target="#exampleModal"><i class="fas fa-user-plus">&nbsp;Add</i>
            </button>

            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Form Karyawan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">

                   <form action="<?php echo e(route('absensi.store')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                      <label for="exampleInputEmail1">Nama Karyawan</label>
                      <input name="nama" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="ketik nama lengkap anda">
                    </div>
                    
                    <div class="form-group">
                      <label for="exampleInputEmail1">Tanggal</label>
                      <input name="tanggal" type="date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Masukan Tanggal">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Time In</label>
                      <input name="time_in" type="time" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="00:00:00">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Time Out</label>
                      <input name="time_out" type="time" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="00:00:00">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Time Break</label>
                      <input name="time_break" type="time" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="00:00:00">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Time End Break</label>
                      <input name="time_breakend" type="time" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="00:00:00">
                    </div>
 
                    <div class="form-group">
                      <label for="exampleFormControlTextarea1">Keterangan</label>
                      <textarea name="keterangan" class="form-control" id="exampleFormControlTextarea1"  placeholder="Keterangan"></textarea>
                    </div>
                    <div class="form-group">
                      <?php

                      $rs = App\Posisi::all();
                      ?>
                      <label for="exampleFormControlSelect1">Posisi</label>
                      <select name="jabatan_id" class="form-control" id="exampleFormControlSelect1" >
                        <option value="">Pilih Posisi</option>
                        <?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($row->id); ?>"><?php echo e($row->posisi); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
              </div>
            </div>
          </div>


 <table class="table table-hover" >
           <thead class="thead-dark">
            <tr>
             <?php $__currentLoopData = $ar_judul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jdl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <th><?php echo e($jdl); ?></th>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tr>
         </thead>
         <tbody>
         <?php $__currentLoopData = $data_absensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr class="table-light">
          <td><?php echo e($no++); ?></td>
          <td><?php echo e($ab->nama); ?></td>
          <td><?php echo e($ab->tanggal); ?></td>
          <td><?php echo e($ab->time_in); ?></td>
          <td><?php echo e($ab->time_out); ?></td>
         <td>
            <a href="<?php echo e(route('absensi.show', $ab
            ->id)); ?>" class="btn btn-warning btn-sm"><i class="fas fa-address-card"></i></a>
            &nbsp; &nbsp;
            <a href="/absensi/<?php echo e($ab->id); ?>/edit" class="btn btn-warning btn-sm"><i class="fas fa-pencil-alt"></i></a>
            &nbsp; &nbsp;
            <a href="/absensi/<?php echo e($ab->id); ?>/delete" class="btn btn-warning btn-sm" onclick="return confirm('Are you sure?')"><i class="fas fa-trash-alt"></i></a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
      </table>



             
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\composer\absensi\resources\views/absensi/index.blade.php ENDPATH**/ ?>