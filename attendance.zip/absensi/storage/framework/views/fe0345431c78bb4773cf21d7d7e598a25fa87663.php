<footer class="footer text-faded footer-info text-center py-5">
    <div class="container">
      <p class="m-0 small">Copyright &copy; Attendance Website 2020</p>
    </div>
  </footer>
  <?php /**PATH C:\xampp\htdocs\absensi\resources\views/layouts/footer.blade.php ENDPATH**/ ?>