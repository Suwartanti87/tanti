<?php $__env->startSection('konten'); ?>
<h1>Edit Data Karyawan</h1>
	<div class="row">	
	<div class="col-lg-12">

 <form action="/karyawan/<?php echo e($karyawan->id); ?>/update" method="POST">
 	<?php echo e(csrf_field()); ?>


  <div class="form-group">
    <label for="exampleInputEmail1">Nama Lengkap</label>
    <input name="nama_karyawan" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="ketik nama lengkap anda" value="<?php echo e($karyawan->nama_karyawan); ?>">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Tanggal Lahir</label>
    <input name="tgl_lahir" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="YYYY-MM-DD" value="<?php echo e($karyawan->tgl_lahir); ?>">
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Jenis Kelamin</label>
    <select name="jenis_kelamin" class="form-control" id="exampleFormControlSelect1" >
    	<option value="">Pilih Jenis Kelamin</option>
    	<option value="L" <?php if($karyawan->jenis_kelamin == 'L'): ?> selected <?php endif; ?>>Laki-Laki</option>
    	<option value="P" <?php if($karyawan->jenis_kelamin == 'P'): ?> selected <?php endif; ?>>Perempuan</option>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Agama</label>
    <select name="agama" class="form-control" id="exampleFormControlSelect1" >
    	<option value="">Pilih Agama</option>
    	<option value="Islam" <?php if($karyawan->agama == 'Islam'): ?> selected <?php endif; ?>>Islam</option>
      <option value="Kristen" <?php if($karyawan->agama == 'Kristen'): ?> selected <?php endif; ?>>Kristen</option>
      <option value="Hindu" <?php if($karyawan->agama == 'Hindu'): ?> selected <?php endif; ?>>Hindu</option>
      <option value="Buddha" <?php if($karyawan->agama == 'Buddha'): ?> selected <?php endif; ?>>Buddha</option>
      <option value="Konghuchu" <?php if($karyawan->agama == 'Konghuchu'): ?> selected <?php endif; ?>>Konghuchu</option>
      <option value="Others" <?php if($karyawan->agama == 'Others'): ?> selected <?php endif; ?>>Others</option>
    </select>
  </div>
  <div class="form-group">
  	<label for="exampleFormControlTextarea1">Alamat</label>
  	<textarea name="alamat" class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="ketik alamat anda"><?php echo e($karyawan->alamat); ?></textarea>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Tanggal Gabung</label>
    <input name="tgl_masuk" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="YYYY-MM-DD" value="<?php echo e($karyawan->tgl_masuk); ?>">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Tanggal Keluar</label>
    <input name="tgl_keluar" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="YYYY-MM-DD" value="<?php echo e($karyawan->tgl_keluar); ?>">
  </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
  </form>
</div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\absensi\resources\views/karyawan/edit.blade.php ENDPATH**/ ?>